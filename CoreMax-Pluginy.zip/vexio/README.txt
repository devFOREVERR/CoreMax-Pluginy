		https://www.cmd5.org/

^^ Tutaj możecie sobie odkodować hasła z coremax_db.yml ^^


